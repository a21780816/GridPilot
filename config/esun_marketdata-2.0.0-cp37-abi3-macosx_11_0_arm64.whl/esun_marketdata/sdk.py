"""
Expose as a single library for user to use

"""
from datetime import datetime, timezone

from esun_marketdata._trade_core import CoreSDK
from esun_marketdata.util import (
    ft_check_password,
    ft_get_password,
    ft_set_password,
    load_credentials,
    remove_credentials,
    setup_keyring,
)
from json import loads
from .rest import RestClientFactory
from .websocket import WebSocketClientFactory

class SDK:
    """Main sdk for esunTrade"""

    def __init__(self, config):
        self.validate_config(config)
        self.config = config
        self.__ip = ""
        self.__AID = config["User"]["Account"]

        if not self.__AID:
            raise TypeError("please setup your config before using this SDK")
        setup_keyring(self.__AID)

        self.__core = None
        self.__sdk_token = None


    @property
    def rest_client(self):
        rest_url = self.get_marketdata_rest_url()
        return RestClientFactory(rest_url=rest_url, sdk_token=self.__sdk_token)

    @property
    def websocket_client(self):
        ws_url = self.get_marketdata_ws_url()
        return WebSocketClientFactory(ws_url=ws_url, sdk_token=self.__sdk_token)


    def validate_config(self, config):
        if not (
            config.has_section("Core")
            and config.has_section("Cert")
            and config.has_section("Api")
            and config.has_section("User")
        ):
            raise TypeError("please fill in config file")
        if not config["Core"].get("Entry"):
            raise TypeError("please give Core Entry value")
        if config["Core"].get("Environment"):
            if (
                config["Core"]["Environment"].lower() == "simulation"
                and config["Core"]["Entry"].find("simulation") == -1
            ):
                raise TypeError("Entry and Environment conflict")

        if (not config["Cert"].get("Path")) or config["Cert"]["Path"].find(
            ".p12"
        ) == -1:
            raise TypeError("please give correct Cert Path")

        if (not config["Api"].get("Key")) or (not config["Api"].get("Secret")):
            raise TypeError("please give correct Api Key and Secret")

        if not config["User"].get("Account"):
            raise TypeError("please give correct User Account")

    def certinfo(self):
        return loads(self.__core.get_certinfo())

    def reset_password(self):
        ft_set_password(self.__AID)
        print("reset_password done!!")

    def login(self):
        """login function"""
        credentials = load_credentials(self.__AID)
        # account_password, cert_password
        self.__core = CoreSDK(
            self.config["Core"]["Entry"],
            self.config["User"]["Account"],
            self.config["Cert"]["Path"],
            credentials["cert_password"],
            self.config["Api"]["Key"],
            self.config["Api"]["Secret"],
        )
        self.__core.login(self.__AID, credentials["account_password"])
        self.__sdk_token = self.get_sdk_token()

    def logout(self):
        remove_credentials(self.__AID)

    def get_sdk_token(self):
        """exchange sdk token function"""
        realtime_token_res = self.__core.exchange_realtime_token()
        sdk_token_res = loads(realtime_token_res)
        return sdk_token_res.get('token')

    def get_marketdata_rest_url(self):
        return self.__core.get_marketdata_rest_url()

    def get_marketdata_ws_url(self):
        return self.__core.get_marketdata_ws_url()

    def get_key_info(self):
        """key info"""
        key_info_res = self.__core.get_key_info()
        return loads(key_info_res)["data"]

    def get_machine_time(self):
        key_info_res = self.__core.get_machine_time()
        return loads(key_info_res)["data"]
